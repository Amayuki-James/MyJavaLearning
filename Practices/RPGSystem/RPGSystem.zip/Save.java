package Practices.RPGSystem;
import java.io.FileNotFoundException;
import java.io.File;
import java.io.IOException;
import java.io.FileWriter;
import java.util.Scanner;

public class Save {
    public static void SaveGame() {
        File f = new File("H:\\Learning\\Programming\\Java\\Practices\\RPGSystem\\save.txt");
        if (f.exists() && !f.isDirectory()) {
            System.out.println("Please choose from the 3 slots you want to save to.");
            Scanner scanner = new Scanner(System.in);
            int SlotChoice = scanner.nextInt();
            scanner.nextLine();
            switch (SlotChoice) {
                case 1 -> SaveToSlot();
                case 2 -> SaveToSlot();
                case 3 -> SaveToSlot();
                default -> System.out.println("Invalid choice. Please enter a valid option.");
            }
            System.out.println("Game saved to slot " + SlotChoice + ".");
        }
        CreateNewSave.createSave();
    }
    
}
